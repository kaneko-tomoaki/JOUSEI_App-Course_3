import pygame                   # ゲーム開発に使用されるPythonのライブラリ グラフィックスやサウンドの処理を簡単に行う
import pymunk                   # 2D物理シミュレーションを行うためのライブラリで、物体の動きや衝突をシミュレートする
import random                   # ランダムな数値を生成
import math                     # 数学的な計算を行う関数を提供
import sys                      # プログラム実行の終了を保証

# 初期化
pygame.init()                                                                   # pygameライブラリを初期化し、pygameの各モジュールを使用可能にするにする         
width, height = 900, 600                                                        # ゲームウィンドウの幅と高さを設定 今回のゲーム画面は、幅が900ピクセル、高さが600ピクセル
screen = pygame.display.set_mode((width, height))                               # 指定した幅と高さでゲーム描画用　ゲームウィンドウを作成し、screenという変数に格納 
# pygame.display.set_caption("Falling Balls Game")
pygame.display.set_caption("Moonlight Gift")                                    # ゲームウィンドウのタイトル「Moonlight Gift」
clock = pygame.time.Clock()                                                     # pygameのClockオブジェクトを作成 ゲームのフレームレートを制御するために使用
background_image = pygame.image.load("images/background_eve.png")             # 指定されたパスから背景画像を読み込み、background_imageという変数に格納
background_image = pygame.transform.scale(background_image, (width, height))    # 画面サイズに合わせてスケーリング

ball_spawn_sound = pygame.mixer.Sound("sounds/sei_ge_suzu03.mp3")              # 指定されたパスから音声ファイルを読み込み、ボールが生成されるときに再生するためのサウンドオブジェクトを作成
ball_merge_sound = pygame.mixer.Sound("sounds/ata_a26.mp3")              # 指定されたパスから音声ファイルを読み込み、ボールが合体するときに再生するためのサウンドオブジェクトを作成
# ball_merge_sound = pygame.mixer.Sound("sounds/fanfare.mp3")
game_over = False                                                               # ゲームの終了状態を示すフラグを初期化 ここでは、ゲームが終了していない状態を示すためにFalseに設定
gameover_sound_played = False
# ゲームの開始からの経過時間
start_ticks = pygame.time.get_ticks()                                           # ゲームスタート時の時間をミリ秒単位で取得し、start_ticksに格納　この値を基に経過時間を計算
# 制限時間（秒）
time_limit = 100                                                                # ゲームの制限時間を100秒に設定 この時間が経過するとゲームオーバー


walls = []                                                                      # 壁の情報を格納するためのリストを初期化 このリストに後ほど壁のオブジェクトが追加される
score = 0                                                                       # ゲームのスコアを初期化 。ゲーム開始時のスコアは0

# ゲームの初期化部分の直後に追加
ball_images = {}                                                                # ボールの画像を格納するための辞書を初期化 この辞書に 異なるサイズのボールの画像をを格納
for i in range(1, 11):                                                          #　1から10までの数値を順に取り出すループを開始このループ内で、異なるサイズのボールの画像を読み込む
    image = pygame.image.load(f"images/ball_{i}.png")                           # 指定されたパスからボールの画像を読み込み、imageという変数に格納 画像のファイル名はball_1.pngからball_10.pngまで
    ball_images[i] = pygame.transform.smoothscale(image, (i*20, i*20))          # 読み込んだボール画像を2倍サイズにスケーリングし、ball_images辞書に格納　辞書のキーはボールのサイズを表す数値
next_ball_type = 1                                                              # 次に生成（生成はpymunkが担当）されるボールのタイプを1（つまり実体はデフォルトサイズ）に設定 この値は、次に生成されるボールのサイズを決定　ボールの画像（見た目：pygameが担当）は実体とは異なるサイズに加工される

# Pymunkのスペースを設定
space = pymunk.Space()                                                          # Pymunkの物理シミュレーション用のスペースを作成し、spaceという変数に格納 このスペース内で物理演算を実施
space.gravity = (0, 1000)                                                       # スペース内の重力を設定　ここでは、下方向に1000の重力がかかるように設定

# 床を設定
floor = pymunk.Segment(space.static_body, (195, height-50), (width-195, height-50), 20) #pymunk.Segmentを使用して、床のセグメントを作成 space.static_body:固定されたボディ 床の始点と終点の座標を指定  床は画面の幅に合わせて左右に195ピクセルの余白を持ち、高さは画面の下から50ピクセルの位置に設定セグメントの厚さは20px
floor.friction = 0.8                                                            # 床の摩擦係数を0.8に設定　摩擦係数が高いほど、オブジェクトが床に接触した際に滑りにくくなる
floor.elasticity = 0.8                                                          # 床の弾性係数を0.8に設定　弾性係数が高いほど、オブジェクトが床に衝突した際に跳ね返りやすくなる
space.add(floor)                                                                # 作成した床のセグメントをpymunkのスペースに追加 物理シミュレーション内で床が有効になる

balls = []                                                                      # ボールの情報を格納するためのリストを初期化 このリストには、後で生成されるボールのオブジェクトが追加される

def create_ball(x, y, update_next, radius=None,):                               # create_ballという関数を定義 新しいボールを指定された位置に生成 (引数として：ボールの生成位置（x, y）,次のボールタイプを更新するかどうか(update_next),ボールの半径(radius)を受け取る)
    global next_ball_type                                                       # 次に生成されるボールのタイプを決定
    if radius is None:                                                          # 半径が指定されていない場合、
        radius = next_ball_type * 10                                            # next_ball_typeに基づいてボールの半径を設定 next_ball_typeが1であれば、半径は10px
    mass = 1                                                                    # ボールの質量を1に設定 質量は物理シミュレーション（現実世界での動きに酷似させる）での動きに影響を与える
    moment = pymunk.moment_for_circle(mass, 0, radius)                          # ボールの慣性モーメントを計算 pymunk.moment_for_circle関数を使って、現実世界での円形のオブジェクトの慣性モーメントを計算
    body = pymunk.Body(mass, moment)                                            # 質量と慣性モーメント（現実世界での回転のしにくさ）を指定しつつボールの物理的なボディを作成し、 pymunk.Bodyオブジェクトを生成
    body.position = x, y                                                        # x,y座標に基づき、ボールの初期位置を設定
    shape = pymunk.Circle(body, radius)                                         # pymunk.Circleを使い、ボールの形状を円として定義し、指定されたボディと半径を持つ円形の形状を作成
    shape.friction = 0.7                                                        # ボールの摩擦係数を0.7に設定 摩擦係数が高いほど、ボールが他のオブジェクトと接触した際に滑りにくくなる
    shape.elasticity = 0.8                                                      # ボールの弾性係数を0.8に設定 弾性係数が高いほど、ボールが衝突した際に跳ね返りやすくなる
    shape.size_label = radius // 10                                             # ボールのサイズを人ではなく、プログラム自身が識別するためのラベルを設定　radiusを10で割った値がラベル　サイズ、衝突・合体等のロジックをプログラム自身が把握するために活用　
    shape.image = ball_images[shape.size_label]                                 # ボールの見た目として使用する画像を設定 ball_imagesの一覧から、size_labelに対応する画像を取得
    space.add(body, shape)                                                      # ボールのボディと形状をpymunkのスペースに追加 pymunkによる物理シミュレーションの対象物とする
    balls.append(shape)                                                         # ボールの形状をballsリストに追加 このリストはゲーム内で使用されるすべてのボールを保持し管理
    shape.collision_type = 1                                                    # ボールの衝突タイプを1に設定　ゲーム内で衝突タイプは1のみなので、ボール同士の衝突をすぐに識別でき、その都度スムーズに処理を行える
    ball_spawn_sound.play()                                                     # ボールが生成時のサウンドを再生 
    if update_next:                                                             # update_nextがTrueの場合,以下の処理を開始
        next_ball_type = random.choice([i for i in range(1, 6)])                # 次に生成されるボールのタイプをランダムに1から5の間で選択　これにより、生成されるボールサイズをランダムに変化させる


def merge_balls(arbiter, space, _):
    global next_ball_type, score  # scoreをglobal変数として参照
    ball1, ball2 = arbiter.shapes

    # 一番大きいサイズのボールのサイズラベルは10
    if ball1.size_label == 10 and ball2.size_label == 10:                       # if文で、ball1とball2の各サイズラベルが10（最大サイズ）であるかどうかをチェック（ball1とball2は合体した様々なサイズのボールを意味する　必ずしも最も大きなボールのことではない）
        balls.remove(ball1)                                                     # ballsリストからball1を削除 サイズに関わらず合体したボール自体は消失する
        balls.remove(ball2)                                                     # ballsリストからball2を削除 サイズに関わらず合体したボール自体は消失する
        space.remove(ball1, ball1.body, ball2, ball2.body)                      # pymunkのスペースからもball1とball2、およびそれらのボディを削除　表示のみならず物理シミュレーションからもこれらのボールが消去される
        ball_merge_sound.play()                                                 # ボール合体時のサウンドを再生。これにより、視覚のみならず聴覚的にも合体が認知できる
        score += ball1.size_label                                               # スコアの更新（加算）　
        return False  
    
    if ball1.size_label == ball2.size_label:                                    # if文でball1とball2のサイズラベルが同じであるかどうかをチェック　これは同じサイズのボール同士が衝突した場合に合体させるための条件
        new_radius = ball1.radius + 10                                          # 合体後の新しいボールの半径を計算 元のボールの半径に10を加えた値が新しい半径
        mid_x = (ball1.body.position.x + ball2.body.position.x) / 2             # 合体後の新しいボールのx座標を計算　ball1とball2のx座標の中間点を新しいボールのx座標とする
        mid_y = (ball1.body.position.y + ball2.body.position.y) / 2             # 合体後の新しいボールのy座標を計算　ball1とball2のx座標の中間点を新しいボールのy座標とする
        create_ball(mid_x, mid_y, False, new_radius)                            # 計算した座標と半径を使って、新しいボールを合体する前の二つのボールの中間地点に生成  update_next（50行目）はFalseに設定されているため、次のボールタイプは更新されない　あらかじめ画面右側に表示されている画像が間違いなく落下してくる
        balls.remove(ball1)                                                     # ballsリストからball1を削除 合体したボールを消す
        balls.remove(ball2)                                                     # ballsリストからball2を削除 合体したボールを消す
        space.remove(ball1, ball1.body, ball2, ball2.body)                      # pymunkのスペースからもball1とball2、およびそれらのボディを削除　これにより、物理シミュレーションからもこれらのボールが消去される
        ball_merge_sound.play()                                                 # ボールが合体したときのサウンドを再生 合体のフィードバックを音で提供
        score += ball1.size_label                                               #　スコアを更新　ball1.size_labelの値をスコアに加算し、合体したボールのサイズに応じたスコアを取得
    return True

collision_handler = space.add_collision_handler(1, 1)                           # 同じタイプのボール同士の衝突を検知し、その衝突をpymnkで処理（ボールの合体）する領域をspace(38行目）内に確保するための関数(add_collision_handler(1,1))を作成し、変数collision_handlerに代入
collision_handler.begin = merge_balls                                           # ボールが実際に衝突した際には、71行目で作成済みのmerge_balls関数を使って、用意された領域内でボールの合体処理を実行（ゲームプレーヤーも目視できる）

def create_walls(space):                                                        # 物理シュミレーション内に「壁」を作成する関数を定義　その壁のためにspace(38行目）を受け取る
    thickness = 20                                                              # 壁の厚さは20pxに設定に設定（ゲーム画面中央部に上を向いたコの字型に配置されている黒い枠）
    global walls                                                                # wallsというグローバル変数を宣言 この変数には、作成した壁の情報が格納される
    walls = [                                                                   # ゲーム画面に配置された配置された上を向いたコの字型のwalls（壁）に関する諸情報
        pymunk.Segment(space.static_body, (195, 97), (195, height - 50), thickness),              # 左の壁の情報　(左上端　ｘ：195, ｙ：97)から(下端　ｘ：195, height（画面の高さ） - 50)までが左の壁の始点と終点の座標・・・この数値を調整するとボールが壁の外に出てGameOutすることを防げる
        pymunk.Segment(space.static_body, (width-195, 97), (width-195, height - 50), thickness),  # 右の壁の情報　(width（画面の幅）-195, 97)から(width（画面の幅-195, height（画面の高さ） - 50)までが右の壁の座標・・・この数値を調整するとボールが壁の外に出てGameOutすることを防げる
    ]
    for wall in walls:
        wall.friction = 1.0                                                     #　壁の摩擦係数を1.0に設定し、オブジェクトが壁に接触した際に滑りにくく調整
        wall.elasticity = 0.95                                                  #  壁の弾性係数を0.95に設定し、オブジェクトが壁に衝突した際に跳ね返りやすくなる
        wall.color = pygame.Color("black")                                      #  壁の色を黒に設定
    space.add(*walls)                                                           #  作成した壁をPymunkのスペースに追加 物理シミュレーション内で壁が有効化される
    walls.extend(walls)                                                         #  wallsリストに自身を追加してみたが、必須ではない

create_walls(space)                                                             #  準備万端 整ったので実際に壁を作成し、物理シミュレーションに追加

def to_pygame(p):
    """Convert pymunk to pygame coordinates"""
    return int(p.x), int(-p.y + height)

# 既存のボールとの重複をチェックする関数
def is_overlapping_with_existing_balls(x, y, radius):
    for ball in balls:
        distance = ((x - ball.body.position.x) ** 2 + (y - ball.body.position.y) ** 2) ** 0.5
        if distance < radius:  # 2つのボールの半径の合計よりも距離が小さい場合
            return True
    return False

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.pos[1] < 100:  # 画面の上部100px内の場合
                if not is_overlapping_with_existing_balls(event.pos[0], event.pos[1], next_ball_type * 10):
                    create_ball(event.pos[0], event.pos[1], True)
            
    screen.blit(background_image, (0, 0))
    
    balls_to_remove = []
    for ball in balls:
        image = ball.image
        angle_degrees = -math.degrees(ball.body.angle)  # ボールの角度を取得し、ラジアンから度に変換
        rotated_image = pygame.transform.rotate(ball.image, angle_degrees)  # 画像を回転させる
        
        # 画像の新しい中心位置を取得
        x, y = int(ball.body.position.x), int(ball.body.position.y)
        rect = rotated_image.get_rect(center=(x,y))

        # 回転した画像を描画
        screen.blit(rotated_image, rect.topleft)

    for ball in balls:
        if ball.body.position.y + ball.radius > height:
            game_over = True
            
    for ball in balls_to_remove:
        space.remove(ball, ball.body)
        balls.remove(ball)

    for wall in walls:
        p1 = int(wall.a[0]), int(wall.a[1])
        p2 = int(wall.b[0]), int(wall.b[1])
        # pygame.draw.line(screen, (0, 0, 0), p1, p2, int(wall.radius))
        pygame.draw.line(screen, (3, 27, 61), p1, p2, int(wall.radius))
    # 経過時間の計算（秒）
    seconds = (pygame.time.get_ticks() - start_ticks) // 1000

    space.step(1/60.0)
    
    thickness = 10
    corner_radius = thickness
    corner_color = (3, 27, 61)
    pygame.draw.line(screen, corner_color, (195, height-50), (width-195, height-50), 20)
    pygame.draw.circle(screen, corner_color, (196, height - 50), corner_radius)
    pygame.draw.circle(screen, corner_color, (width-194, height - 50), corner_radius)
    pygame.draw.circle(screen, corner_color, (196, 97), corner_radius)
    pygame.draw.circle(screen, corner_color, (width-194, 97), corner_radius)

    # pygame.draw.line(screen, (0, 0, 0), (195, height-50), (width-195, height-50), 20)
    # pygame.draw.circle(screen, (0, 0, 0), (196, height - 50), corner_radius)
    # pygame.draw.circle(screen, (0, 0, 0), (width-194, height - 50), corner_radius)
    # pygame.draw.circle(screen, (0, 0, 0), (196, 97), corner_radius)
    # pygame.draw.circle(screen, (0, 0, 0), (width-194, 97), corner_radius)

    # 画面の上100pxの部分に暗い矩形を描画
    # dark_surface = pygame.Surface((width, 75), pygame.SRCALPHA)  # 半透明のサーフェスを作成
    # dark_surface.fill((0, 0, 0, 128))  # RGBAで黒色の半透明の色を設定
    # screen.blit(dark_surface, (0, 0))  # サーフェスを画面に描画

    next_ball_image = ball_images[next_ball_type]
    next_ball_center_pos = (width - 90 - next_ball_image.get_width() // 2, 197 - next_ball_image.get_height() // 2)
    screen.blit(next_ball_image, next_ball_center_pos)

    # 画面の指定された位置にスコアを表示
    font = pygame.font.Font('BitCheese10(sRB).TTF', 36) 
    score_text = font.render(f'SCORE: {score}', True, (255, 255, 255))
    score_position = (50, 25)  # 「2」の位置
    screen.blit(score_text, score_position)

    screen.blit(font.render('NEXT: ', True, (255, 255, 255)), (width - 168, 98))

    text = font.render(f"Time: {time_limit - seconds}", True, (255, 255, 255))
    screen.blit(text, (width - 200, 25))
    if seconds == 100:
        game_over = True

    if game_over:
        if not gameover_sound_played:
            gameover_sound = pygame.mixer.Sound("sounds/do_ra.mp3")
            gameover_sound.play()
            gameover_sound_played = True
        screen.fill((0, 11, 27, 180))  # 半透明の黒で画面を暗くします。
        
        font = pygame.font.Font('BitCheese10(sRB).TTF', 54) 
        gameover_text = font.render("Gameover", 1, (250, 254, 200))
        gameover_pos = gameover_text.get_rect(center=(width/2, height/2 - 40))

        screen.blit(gameover_text, gameover_pos)


        score_text = font.render(f"Score: {score}", 1, (250, 254, 200))
        score_pos = score_text.get_rect(center=(width/2, height/2 + 40))
        screen.blit(score_text, score_pos)
        # gameover_sound = pygame.mixer.Sound("sounds/do_ra.mp3")
        # gameover_sound.play()     

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit() 